Problem Statement - 

Create an async method to count No. of employees working above age 50.
Fetch will give the result of employees with
    -- id
    -- employee_name
    -- employee_salary
    -- employee_age
    -- profile_image

Use TDD approach and support the logic with meaningful test cases.